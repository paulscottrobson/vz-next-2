

#include <sound.h>
#include <stdio.h>

#include <conio.h>
#include <stdlib.h>
#include <ctype.h>
#include <vz.h>

int main()
{
printf("\n\n");
printf(" Z88DK built in sound Effects.\n\n");
printf("Four libraries, each having 7 \n");
printf("sound effects.");
printf("\n\n");
printf("Press <any> key to scroll\n");
printf("  through each of them... \n\n");


printf("...Library 1 FX 0\n"); do {bit_fx(0);} while(!vz_inch() )  ;
printf("...Library 1 FX 1\n"); do {bit_fx(1);} while(!vz_inch() )  ;
printf("...Library 1 FX 2\n"); do {bit_fx(2);} while(!vz_inch() )  ;
printf("...Library 1 FX 3\n"); do {bit_fx(3);} while(!vz_inch() )  ;
printf("...Library 1 FX 4\n"); bit_fx(4);bit_fx(4);
printf("...Library 1 FX 5\n"); do {bit_fx(5);} while(!vz_inch() )  ;
printf("...Library 1 FX 6\n"); do {bit_fx(6);} while(!vz_inch() )  ;  /* high pitch single note, teckno 8?
printf("...Library 1 FX 7\n"); do {bit_fx(7);} while(!vz_inch() )  ;

printf("...Library 2 FX 0\n"); do {bit_fx2(0);} while(!vz_inch() )  ; /* medium pitch single note, teckno 8?
printf("...Library 2 FX 1\n"); do {bit_fx2(1);} while(!vz_inch() )  ;
printf("...Library 2 FX 2\n"); do {bit_fx2(2);} while(!vz_inch() )  ;
printf("...Library 2 FX 3\n"); do {bit_fx2(3);} while(!vz_inch() )  ;
printf("...Library 2 FX 4\n"); do {bit_fx2(4);} while(!vz_inch() )  ;
printf("...Library 2 FX 5\n"); do {bit_fx2(5);} while(!vz_inch() )  ;	/*  Base, techno */
printf("...Library 2 FX 6\n"); do {bit_fx2(6);} while(!vz_inch() )  ;
printf("...Library 2 FX 7\n"); do {bit_fx2(7);} while(!vz_inch() )  ;

printf("...Library 3 FX 0\n"); do {bit_fx3(0);} while(!vz_inch() )  ;
printf("...Library 3 FX 1\n"); do {bit_fx3(1);} while(!vz_inch() )  ;
printf("...Library 3 FX 2\n"); do {bit_fx3(2);} while(!vz_inch() )  ;
printf("...Library 3 FX 3\n"); do {bit_fx3(3);} while(!vz_inch() )  ;
printf("...Library 3 FX 4\n"); do {bit_fx3(4);} while(!vz_inch() )  ;
printf("...Library 3 FX 5\n"); do {bit_fx3(5);} while(!vz_inch() )  ;
printf("...Library 3 FX 6\n"); do {bit_fx3(6);} while(!vz_inch() )  ;
printf("...Library 3 FX 7\n"); do {bit_fx3(7);} while(!vz_inch() )  ;

printf("...Library 4 FX 0\n"); do {bit_fx4(0);} while(!vz_inch() )  ;
printf("...Library 4 FX 1\n"); bit_fx4(1);
printf("...Library 4 FX 2\n"); do {bit_fx4(2);} while(!vz_inch() )  ;
printf("...Library 4 FX 3\n"); do {bit_fx4(3);} while(!vz_inch() )  ;
printf("...Library 4 FX 4\n"); do {bit_fx4(4);} while(!vz_inch() )  ;
printf("...Library 4 FX 5\n"); do {bit_fx4(5);} while(!vz_inch() )  ;
printf("...Library 4 FX 6\n"); do {bit_fx4(6);} while(!vz_inch() )  ;
printf("...Library 4 FX 7\n"); do {bit_fx4(7);} while(!vz_inch() )  ;


	printf("01 \n");

        bit_synth (50,200,202,40,41);
        bit_synth (50,200,202,37,38);
        bit_synth (50,200,202,33,34);
        bit_synth (50,200,202,40,41);

        bit_synth (50,177,179,33,34);
        bit_synth (50,177,179,37,38);
        bit_synth (50,150,152,40,41);
        bit_synth (50,150,152,44,45);

	printf("02 \n");
        bit_synth (50,200,202,40,41);
        bit_synth (50,200,202,37,38);
        bit_synth (50,200,202,33,34);
        bit_synth (50,200,202,40,41);
        bit_synth (50,200,202,40,41);
        bit_synth (50,200,202,37,38);
        bit_synth (50,200,202,33,34);
        bit_synth (50,200,202,40,41);

        bit_synth (50,177,179,33,34);
        bit_synth (50,177,179,37,38);
        bit_synth (50,150,152,40,41);
        bit_synth (50,150,152,44,45);
        bit_synth (50,177,179,33,34);
        bit_synth (50,177,179,37,38);
        bit_synth (50,150,152,40,41);
        bit_synth (50,150,152,44,45);



	printf("03 \n");
        bit_synth (50,200,202,40,41);
        bit_synth (50,200,202,37,38);
        bit_synth (50,200,202,40,41);
        bit_synth (50,200,202,37,38);
        bit_synth (50,200,202,33,34);
        bit_synth (50,200,202,40,41);
        bit_synth (50,200,202,33,34);
        bit_synth (50,200,202,40,41);

        bit_synth (50,177,179,33,34);
        bit_synth (50,177,179,37,38);
        bit_synth (50,177,179,33,34);
        bit_synth (50,177,179,37,38);
        bit_synth (50,150,152,40,41);
        bit_synth (50,150,152,44,45);
        bit_synth (50,150,152,40,41);
        bit_synth (50,150,152,44,45);


	printf("04 \n");
        bit_synth (50,200,202,40,41);
        bit_synth (50,200,202,40,41);
        bit_synth (50,200,202,37,38);
        bit_synth (50,200,202,37,38);
        bit_synth (50,200,202,40,41);
        bit_synth (50,200,202,40,41);
        bit_synth (50,200,202,37,38);
        bit_synth (50,200,202,37,38);
        bit_synth (50,200,202,33,34);
        bit_synth (50,200,202,33,34);
        bit_synth (50,200,202,40,41);
        bit_synth (50,200,202,40,41);
        bit_synth (50,200,202,33,34);
        bit_synth (50,200,202,33,34);
        bit_synth (50,200,202,40,41);
        bit_synth (50,200,202,40,41);

        bit_synth (50,177,179,33,34);
        bit_synth (50,177,179,33,34);
        bit_synth (50,177,179,37,38);
        bit_synth (50,177,179,37,38);
        bit_synth (50,177,179,33,34);
        bit_synth (50,177,179,33,34);
        bit_synth (50,177,179,37,38);
        bit_synth (50,177,179,37,38);
        bit_synth (50,150,152,40,41);
        bit_synth (50,150,152,40,41);
        bit_synth (50,150,152,44,45);
        bit_synth (50,150,152,44,45);
        bit_synth (50,150,152,40,41);
        bit_synth (50,150,152,40,41);
        bit_synth (50,150,152,44,45);
        bit_synth (50,150,152,44,45);


	printf("05 \n");

        bit_synth (50,200,202,40,41);
        bit_synth (200,200,202,40,41);
        bit_synth (50,200,202,37,38);
        bit_synth (200,200,202,37,38);
        bit_synth (50,200,202,33,34);
        bit_synth (200,200,202,33,34);
        bit_synth (50,200,202,40,41);
        bit_synth (200,200,202,40,41);

        bit_synth (50,177,179,33,34);
        bit_synth (200,177,179,33,34);
        bit_synth (50,177,179,37,38);
        bit_synth (200,177,179,37,38);
        bit_synth (50,150,152,40,41);
        bit_synth (200,150,152,40,41);
        bit_synth (50,150,152,44,45);
        bit_synth (200,150,152,44,45);









	printf("------------------- \n");
	printf("1 \n");

        bit_synth (50,200,202,40,40);
        bit_synth (50,200,202,37,37);
        bit_synth (50,200,202,33,33);
        bit_synth (50,200,202,40,40);

        bit_synth (50,200,202,40,40);
        bit_synth (50,200,202,37,37);
        bit_synth (50,200,202,33,33);
        bit_synth (50,200,202,40,40);

	printf("2 \n");
        bit_synth (50,160,162,50,50);
        bit_synth (50,160,162,44,44);
        bit_synth (50,200,202,40,40);
        bit_synth (50,200,202,50,50);

        bit_synth (50,160,162,50,50);
        bit_synth (50,160,162,44,44);
        bit_synth (50,200,202,40,40);
        bit_synth (50,200,202,50,50);

	printf("3 \n");
        bit_synth (50,160,162,50,50);
        bit_synth (50,160,162,33,33);
        bit_synth (50,200,202,37,37);
        bit_synth (50,200,202,40,40);

        bit_synth (50,160,162,50,50);
        bit_synth (50,160,162,33,33);
        bit_synth (50,200,202,37,37);
        bit_synth (50,200,202,40,40);

	printf("4 \n");


        bit_synth (50,150,152,44,44);
        bit_synth (50,150,152,40,40);
        bit_synth (50,177,179,37,37);
        bit_synth (50,177,179,44,44);

        bit_synth (50,150,152,44,44);
        bit_synth (50,150,152,40,40);
        bit_synth (50,177,179,37,37);
        bit_synth (50,177,179,44,44);

	printf("5 \n");

        bit_synth (50,177,177,33,33);
        bit_synth (50,177,177,37,37);
        bit_synth (50,150,150,40,40);
        bit_synth (50,150,150,44,44);


	printf("============== \n");

        bit_synth (50,300,300,33,33);
        bit_synth (50,300,300,37,37);
        bit_synth (50,200,200,40,40);
        bit_synth (50,200,200,44,44);


        bit_synth (50,300,300,33,33);
        bit_synth (50,300,300,37,37);
        bit_synth (50,200,200,40,40);
        bit_synth (50,200,200,44,44);

        bit_synth (50,300,300,33,33);
        bit_synth (50,300,300,37,37);
        bit_synth (50,200,200,40,40);
        bit_synth (50,200,200,44,44);



        bit_synth (80,300,300,33,33);
        bit_synth (80,300,300,37,37);
        bit_synth (80,200,200,40,40);
        bit_synth (80,200,200,44,44);

        bit_synth (80,300,300,33,33);
        bit_synth (80,300,300,37,37);
        bit_synth (80,200,200,40,40);
        bit_synth (80,200,200,44,44);

        bit_synth (80,300,300,33,33);
        bit_synth (80,300,300,37,37);
        bit_synth (80,200,200,40,40);
        bit_synth (80,200,200,44,44);



	printf("\n\nLow tones \n");
	printf("1st theme \n");

        bit_synth (100,200,200,40,40);
        bit_synth (100,200,200,33,33);

        bit_synth (100,177,177,37,37);
        bit_synth (100,150,150,44,44);

        bit_synth (100,160,160,50,50);
        bit_synth (100,200,200,40,40);

        bit_synth (100,133,133,44,44);
        bit_synth (100,150,150,44,44);

        bit_synth (100,160,160,50,50);
        bit_synth (100,200,200,40,40);

        bit_synth (100,150,150,44,44);
        bit_synth (100,177,177,37,37);

        bit_synth (100,133,133,40,40);
        bit_synth (100,133,133,44,44);

        bit_synth (150,200,200,50,50);




	printf("Variation on 1st theme \n");

        bit_synth (50,200,200,40,40);
        bit_synth (50,200,200,37,37);
        bit_synth (50,200,200,33,33);
        bit_synth (50,200,200,40,40);

        bit_synth (50,177,177,33,33);
        bit_synth (50,177,177,37,37);
        bit_synth (50,150,150,40,40);
        bit_synth (50,150,150,44,44);

        bit_synth (50,160,160,50,50);
        bit_synth (50,160,160,44,44);
        bit_synth (50,200,200,40,40);
        bit_synth (50,200,200,50,50);

        bit_synth (50,133,133,44,44);
        bit_synth (50,133,133,50,50);
        bit_synth (50,150,150,44,44);
        bit_synth (50,150,150,40,40);

        bit_synth (50,160,160,50,50);
        bit_synth (50,160,160,33,33);
        bit_synth (50,200,200,37,37);
        bit_synth (50,200,200,40,40);

        bit_synth (50,150,150,44,44);
        bit_synth (50,150,150,40,40);
        bit_synth (50,177,177,37,37);
        bit_synth (50,177,177,44,44);

        bit_synth (50,133,133,40,40);
        bit_synth (50,133,133,37,37);
        bit_synth (50,133,133,44,44);
        bit_synth (50,133,133,40,40);

        bit_synth (50,200,200,50,50);
        bit_synth (50,200,200,40,40);
        bit_synth (50,200,200,50,50);



	printf("\n\nDistortion \n");
        bit_synth (100,200,201,40,41);
        bit_synth (100,200,201,33,34);
        bit_synth (100,177,178,37,38);
        bit_synth (100,150,151,44,45);
        bit_synth (100,160,161,50,51);
        bit_synth (100,200,201,40,41);
        bit_synth (100,133,134,44,45);
        bit_synth (100,150,151,44,45);
        bit_synth (100,160,161,50,51);
        bit_synth (100,200,201,40,41);
        bit_synth (100,150,151,44,45);
        bit_synth (100,177,178,37,38);
        bit_synth (100,133,134,40,41);
        bit_synth (100,133,134,44,45);
        bit_synth (150,200,201,50,51);

	printf("\n\nDistortion 2\n");
        bit_synth (100,200,202,40,41);
        bit_synth (100,200,202,33,34);
        bit_synth (100,177,179,37,38);
        bit_synth (100,150,152,44,45);
        bit_synth (100,160,162,50,51);
        bit_synth (100,200,202,40,41);
        bit_synth (100,133,135,44,45);
        bit_synth (100,150,152,44,45);
        bit_synth (100,160,162,50,51);
        bit_synth (100,200,202,40,41);
        bit_synth (100,150,152,44,45);
        bit_synth (100,177,179,37,38);
        bit_synth (100,133,135,40,41);
        bit_synth (100,133,135,44,45);
        bit_synth (150,200,202,50,51);


	printf("Variation on 1st theme \n");

        bit_synth (50,200,201,40,41);
        bit_synth (50,200,201,37,38);
        bit_synth (50,200,201,33,34);
        bit_synth (50,200,201,40,41);

        bit_synth (50,177,178,33,34);
        bit_synth (50,177,178,37,38);
        bit_synth (50,150,151,40,41);
        bit_synth (50,150,151,44,45);

        bit_synth (50,160,161,50,51);
        bit_synth (50,160,161,44,45);
        bit_synth (50,200,201,40,41);
        bit_synth (50,200,201,50,51);

        bit_synth (50,133,134,44,45);
        bit_synth (50,133,134,50,51);
        bit_synth (50,150,151,44,45);
        bit_synth (50,150,151,40,41);

        bit_synth (50,160,161,50,51);
        bit_synth (50,160,161,33,34);
        bit_synth (50,200,201,37,38);
        bit_synth (50,200,201,40,41);

        bit_synth (50,150,151,44,45);
        bit_synth (50,150,151,40,41);
        bit_synth (50,177,178,37,38);
        bit_synth (50,177,178,44,45);

        bit_synth (50,133,134,40,41);
        bit_synth (50,133,134,37,38);
        bit_synth (50,133,134,44,45);
        bit_synth (50,133,134,40,41);

        bit_synth (50,200,201,50,51);
        bit_synth (50,200,201,40,41);
        bit_synth (50,200,201,50,51);


}
